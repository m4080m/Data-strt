#include <stdio.h>
#include "CQueue.h"

int main(void)
{
	Que queue;
	int data;
	QInit(&queue);

	Enqueue(&queue,1);
	Enqueue(&queue,2);
	Enqueue(&queue,3);
	Enqueue(&queue,4);
	Enqueue(&queue,5);

	while(!QEmpty(&queue)){
		printf("%d ",Dequeue(&queue));
	}
}
